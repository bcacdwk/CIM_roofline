# Roofline模型背景：GPU基准与CIM新范式重构

> **本文档定位**：提炼针对 GPU Roofline 与 CIM Roofline 的理论讨论，作为后续设计论证的背景参考。
> - 第1章：严格复现 GPU Roofline 的经典定义（Williams-Patterson 2009, Samuel Williams）
> - 第2章：分析为何 GPU Roofline 不能直接移植到 CIM 平台
> - 第3章：以 Producer-Consumer 为统一抽象，给出 CIM Roofline 的**候选重构方案**（待定）
> - 第4章：相关文献 review——确认 CIM Roofline 目前是一块真空地带
> - 第5章：待解决的开放问题

---

## 第一章 GPU Roofline：经典定义

### 1.1 任何一个**计算平台**的两个关键指标：算力π 和 带宽β

- **算力 π**：计算性能吞吐的上限，每秒最多的整型/浮点运算次数
  - 单位：(FL)OPS，或 (FL)OP/s

- **带宽 β**：内存交换吞吐的上限，每秒最大的数据 I/O 交换量
  - 单位：Byte/s

- **计算强度上限 I_max = π / β**：该计算平台，单位内存交换最多被用来进行多少次计算
  - 单位：(FL)OPS / Byte

### 1.2 任何一个**网络模型**的两个关键指标：计算量 和 访存量

- **计算量**：对于单个输入样本进行完整前向传播，发生的总浮点运算次数，即计算**时间复杂度**
  - 单位：(FL)OPs

- **访存量**：输入样本经过前向传播得到输出结果的总内存占用，即权重+输出的模型**空间复杂度**
  - 单位：Bytes

- **计算强度 I = 计算量 / 访存量**：该网络模型的内存使用效率，每 Byte 内存交换最终用于多少次浮点运算
  - 单位：(FL)OPs / Byte

### 1.3 Roofline 模型定义

**Roofline 模型**：给定 计算量/访存量 的模型，在给定 算力/带宽 的计算平台上运行的**理论性能上限**（模型受限于平台）。

- **理论性能 P**：模型在计算平台上所能达到的理论每秒最高浮点运算次数
  - 单位：(FL)OPS 或 (FL)OP/s

### 1.4 Roofline 的四条关键规则

1. **平台的 π 和 β 决定了最大性能上限的形状，即 Roofline**
2. **模型的计算强度 I 作为 x-axis**，根据 Roofline 形状确定最高理论性能上限 P
3. **计算强度越低 (I 小)** → 最高性能被带宽 β 限制 → **Memory-bound**
   **计算强度越高 (I 大)** → 最高性能被算力 π 限制 → **Compute-bound**
4. **直觉**：
   - x 轴 OPs/Byte ←→ 任务的**空间复杂度**
   - y 轴 OPs/s    ←→ 任务的**时间复杂度**

> **这条"时间复杂度 vs 空间复杂度"的直觉是GPU Roofline最深刻的insight**。Roofline 本质是在回答：给定一个具有特定时空复杂度属性 (I = 空间/计算的比例) 的 workload，在一个具有特定时空处理能力 (π 和 β) 的硬件上，能以什么时间代价运行？

### 1.5 经典 Roofline 形状

```
  P [OP/s]       ┌───────────── Peak Compute π (硬件算力上限)
                 │  ← Compute-bound region
                 │   (性能受 π 约束，与 I 无关)
                 │
                 │ Ridge Point
                 │ I_max = π / β
                 │/
                ╱
              ╱ ← Memory-bound region
            ╱    P = I × β (性能被 I × β 约束)
          ╱
        ╱
      ╱    Slope = β (带宽)
    ╱
   ─┼─────────────────────────────── I = OPs/Byte
   0
```

**两条"屋檐"**：
- 水平线 P = π：硬件算力上限（compute ceiling）
- 斜线 P = I × β：带宽拉起的 memory-bound ceiling

两者取 **min**，得到实际可达性能 P = min(π, I × β)。

---

## 第二章 CIM Roofline：为什么需要重构

### 2.1 GPU Roofline 的物理前提

回溯 GPU Roofline 成立的三个关键前提：

1. **二阶段 pipeline**：数据在 memory 和 compute 之间单一路径流动
2. **compute 有明确吞吐上限**：compute engine 的 FLOPs/s 是硬件固定
3. **data movement 有明确带宽**：memory 的 Byte/s 是硬件固定

**三者共同构成 "compute + memory 双 bound" 的 Roofline 框架**。

### 2.2 CIM 违反的前提

CIM 架构打破了上述 GPU 框架的所有三个前提：

| 前提 | GPU | CIM |
|------|-----|-----|
| **pipeline 阶段数** | 2 阶段 (memory ↔ compute) | 3 阶段 (input → array → output)，两个interface |
| **compute 吞吐** | 有明确上限 (Peak FLOPs) | 阵列内 analog MAC **"无限并行"**，本身不构成 bottleneck |
| **数据搬运** | 单一 memory channel 的 bytes/s | **两路独立** data flow：<br>(a) 输入侧 WL/DAC 输入<br>(b) 输出侧 BL/ADC 输出 |

**关键结论**：
- CIM 中**"计算"不是 bottleneck**（权重驻留阵列、MAC 一次 cycle 并行完成）
- CIM 的 bottleneck **发生在两个 interface**（输入端 & 输出端），而不是 compute 本身
- CIM 有**两个独立带宽**（input BW 和 output BW），不能用 GPU 的单一 β 表达

### 2.3 从 "Memory-Compute" 到 "Producer-Consumer" 的抽象重构

为了在保留 Roofline 形状的同时适配 CIM 物理现实，需要把 bound 的 framing **从物理硬件层面 (Memory / Compute)** 抽象到 **pipeline 角色层面 (Producer / Consumer)**：

| 范式 | Producer（供给端） | Consumer（消费端） | 数据单位 |
|------|------------------|------------------|----------|
| **GPU** | Memory (DRAM/HBM) | Compute engine (FP units) | Byte |
| **CIM** | Input driver (DAC + WL broadcast + array settling) | Output extractor (BL sensing + ADC + adder tree / output bus) | input value / output value |

**两个框架的 bottleneck 本质相同：pipeline 中的 producer-consumer rate mismatch**：
- GPU 里 memory 供不上 → compute stall
- CIM 里 input 灌不进 → ADC stall
- 反向亦然

**这个重构有两个价值**：

1. **对偶性保留**：Producer-Consumer 是比 Memory-Compute 更底层的抽象，GPU framework 变成其特例
2. **通用于所有 CIM**：DCIM (SRAM-based)、ACIM (RRAM / PCM / FeFET / Flash)、NVM-CIM 都遵循同一 producer-consumer 框架，只是物理实现不同

### 2.4 CIM 中 Producer 和 Consumer 的具体物理构成

| Side | 物理组成 | 延时来源 |
|------|---------|---------|
| **Producer (供给端)** | DAC → WL driver → array 响应 (settling) → 寄生电容电阻 RC 延时 | T_array_cycle ≈ 14 ns (典型) |
| **Consumer (消费端)** | BL sensing → ADC → adder tree (ACIM) 或 digital summation tree (DCIM) → output bus | T_ADC × (L / N_ADC) |

**CIM 的两个工程并行度约束，恰好对应 Producer 和 Consumer 两侧**：
- **行并行度 (WL 同时激活数)** → Producer 侧带宽决定因素
  - 受 SNR、DAC 数量、WL driver 能力限制
- **列并行度 (N_ADC)** → Consumer 侧带宽决定因素
  - 受面积、功耗预算、ADC 数量限制

### 2.5 CIM 的两种 bound 的物理含义

| bound 类型 | 物理机制 | 对应 GPU |
|-----------|---------|---------|
| **Supply-bound (Producer 慢)** | 一次阵列 cycle (T_array) 还没完成，ADC 已在 idle 等下一组 outputs | GPU memory-bound：compute stall waiting for data |
| **Extract-bound (Consumer 慢)** | ADC 还在把上一 cycle 的 outputs 扫描完，producer 必须等待才能启动新 cycle (否则 analog output 会被覆盖) | GPU compute-bound：memory-delivered data 待在 cache 等 compute engine 处理 |

**Supply-bound 与 GPU memory-bound 在 stall 语义上完全同构**。
**Extract-bound 是 CIM 独有的新 bound**——source 是"data domain 转换"而非"compute 上限"。

---

## 第三章 CIM Roofline：候选重构方案（待定）

> ⚠️ **本章方案 tentative，存在未解决的 open questions**。主要 concerns 见第 5 章。

### 3.1 候选方案 A：Y = outputs / sec（"Output-rate" Roofline）

**这是量纲对偶性最干净的版本**。

- **X-axis: II = outputs / cycle** (workload intensity, = N_out for GEMV)
  - 物理意义：每次 array cycle 产生多少个有效 output
- **Y-axis: outputs / sec** (throughput)

**两条ceiling**：
- **Supply-bound slope**: Y = II × (1 / T_array)
  - Slope = 1 / T_array [cycles/sec] (hardware array 循环速率)
- **Extract-bound plateau**: Y = N_ADC / T_ADC
  - Ceiling [outputs/sec] (纯 hardware，与 workload 无关)

**Ridge**：II_ridge = (N_ADC × T_array) / T_ADC
- 典型值 (N_ADC=64, T_array=14ns, T_ADC=10ns)：**II_ridge ≈ 90**

### 3.2 候选方案 B：Y = MACs / sec（"MAC-rate" Roofline）

**这是更贴近"有用 compute"的版本，但量纲对偶性稍弱**。

- **X-axis: II = MACs / input_value** (= N_out for GEMV)
- **Y-axis: MACs / sec**

**两条 ceiling**：
- **Supply-bound slope**: Y = II × B_supply = N_out × (N_in / T_array) → 仍线性 in II
- **Extract-bound plateau**: Y = OI × B_extract = N_in × (N_ADC / T_ADC)
  - OI = Output Intensity = MACs per output = N_in
  - **注意**：plateau 带 OI 因子（= N_in），与 workload 有关

**Ridge** 同 A：II = N_ADC × T_array / T_ADC ≈ 90

### 3.3 候选方案量纲对照（与 GPU 严格比较）

**方案 A (outputs/sec)**：

| 维度 | GPU Roofline | CIM Roofline (方案 A) | 对偶 |
|------|--------------|----------------------|------|
| **Y-axis** | FLOPs/sec = work / time | outputs/sec = work_unit / time | ✓ |
| **X-axis** | AI = FLOPs/Byte = work / data_unit | II = outputs/cycle = work_unit / data_unit | ✓ |
| **Slope** | BW = Byte/sec = data_unit / time | 1/T_array = cycles/sec = data_unit / time | ✓ |
| **Ceiling** | Peak FLOPs = work / time | N_ADC/T_ADC = outputs/sec | ✓ (纯 hardware) |
| **Ridge** | I_max = π / β | II_ridge = N_ADC·T_array / T_ADC | ✓ |

**方案 B (MACs/sec)**：

| 维度 | GPU Roofline | CIM Roofline (方案 B) | 对偶 |
|------|--------------|----------------------|------|
| **Y-axis** | FLOPs/sec | MACs/sec | ✓ |
| **X-axis** | AI = FLOPs/Byte | II = MACs/input_value | ✓ |
| **Slope** | BW = Byte/sec | B_supply = N_in/T_array [input/sec] | ✓ |
| **Ceiling** | Peak FLOPs (纯 hardware) | OI × N_ADC/T_ADC **(含 workload 因子 OI)** | **✗** |
| **Ridge** | I_max = π / β | II_ridge = N_ADC·T_array / T_ADC | ✓ |

### 3.4 Roofline 候选图（方案 A）

```
═══════════════════════════════════════════════════════════════════════════
                            GPU Roofline (baseline)
═══════════════════════════════════════════════════════════════════════════

  Y = FLOPs/sec                 Peak FLOPs ──────────────────────────
  [compute/time]                  ╱  (Consumer ceiling, 纯 hardware)
                                ╱
                              ╱  ← Ridge: AI = π/β
                            ╱
                          ╱   Memory-bound region (Producer 慢)
                        ╱     Y = AI × BW
                      ╱       Slope = BW [Byte/sec]
                    ╱         (Producer rate, hardware)
                  ╱
                ╱
              ╱
            ╱
          ╱
        ╱
   ─────────────────────→    X = AI = FLOPs/Byte
                               [compute / data_unit]


═══════════════════════════════════════════════════════════════════════════
                      CIM Roofline (候选方案 A, Tentative)
═══════════════════════════════════════════════════════════════════════════

  Y = outputs/sec             N_ADC / T_ADC ──────────────────────
  [output/time]                ╱  (Consumer ceiling, 纯 hardware)
                             ╱
                           ╱  ← Ridge: II = N_ADC·T_array / T_ADC ≈ 90
                         ╱
                       ╱     Supply-bound region (Producer 慢)
                     ╱       Y = II × (1 / T_array)
                   ╱         Slope = 1/T_array [cycle/sec]
                 ╱           (Producer rate, hardware)
               ╱
             ╱
           ╱
         ╱
       ╱
     ╱
   ─────────────────────→    X = II = outputs/cycle
                               [output / data_unit]
```

### 3.5 Ridge Point 的物理含义

Ridge 对应 "T_supply = T_extract" 的 workload 边界：

- **II < II_ridge (small output per cycle)**：array read 比 ADC 抽取慢，供给端 bottleneck
  - 优化方向：提高 array cycle 速率、减小 T_array、增加 WL 并行激活数
- **II > II_ridge (large output per cycle)**：ADC 成为 bottleneck，供给端有富余
  - 优化方向：增加 N_ADC、减小 T_ADC、压缩 ADC bit width

### 3.6 Stall 机制：producer-consumer 对偶

| Stall 场景 | 发生机制 | GPU 对应 |
|-----------|---------|---------|
| **Supply-stall** | T_array cycle 未完成，ADC idle | Memory-bound: compute stalls |
| **Extract-stall** | ADC 还在抽取上一批 outputs，新 cycle 被阻塞 | Compute-bound: memory buffer 堆积 |

**关键点：CIM 也存在 stall**，与 GPU 机制对偶；stall 发生的"等待对象"是不同阶段（数据 vs 物理翻转），但 rate mismatch 的 framework 完全同构。

### 3.7 候选方案的 Innovation 映射（CIM Roofline 下的优化语义）

| 优化 | Roofline 效果 | GPU 对应 |
|------|-------------|---------|
| **BL gating / mask cache** | II 降低，工作点**左移向 ridge**，甚至跨入 supply-bound region | GPU: 减少 memory traffic (间接降 AI)，但GPU上此操作一般只能让 AI 上升 (sparsity 减计算多于减数据) |
| **ADC-Softmax pipeline** | 不移动 Roofline 点，但把 extract-bound 下 ADC 占用时间内空闲的 digital compute slot 利用起来 | GPU: compute-bound 下 memory-idle 期的 prefetch |
| **WL gating (sparse SV)** | 降低每个 output 的 OI (depth)，plateau 整体**下移** | 类似 GPU 上 sparsity 减少 effective FLOPs，workload 点下移 |
| **PD 融合** | 同一 producer/consumer infra 服务两类 token，Roofline 不变但消除 mode-switch overhead | GPU: unified memory 无直接对偶 (GPU memory 天然 unified) |

---

## 第四章 文献 review：CIM Roofline 是真空地带

### 4.1 Verhelst, Benini, Verma (IEEE JSSC 2025)

**标题**："How to keep pushing ML accelerator performance? Know your rooflines!"
**引用**：arXiv 2505.16346 / DOI 10.1109/JSSC.2025.3553765

**核心贡献**：
- 提出 **enhanced multi-level Roofline model**，把存储层次 (register/SRAM/DRAM) 划分为多个 bandwidth 层级
- 首次 **系统地讨论 IMC 在 Roofline 上的位置**
- 对 IMC 的 Roofline 影响做出两条论断：
  - (a) IMC "boosts the compute-bound roofline" — 因为 IMC 提高了有效算力密度
  - (b) IMC "enables increased levels of reuse, moving workload operating points further into the compute-bound regime"

**与本文 framework 的差异**：
- Verhelst 等把 IMC 视为 **把 classical GPU Roofline 的 compute-ceiling 向上抬升**
- **没有重构 Roofline 的 bound 本质**，仍然沿用 "memory-bound + compute-bound" 框架
- 没有识别 ADC / DAC 作为独立 bound
- 没有 producer-consumer 重构

### 4.2 NSF 论文 (par.nsf.gov 10526902, IEEE Nanotechnology Magazine 2024)

**标题**："Quantitative Roofline-based analysis of digital and analog CIM..."

**核心内容**：
- 用 **classical Roofline model** 对比 CIM DLA vs TPU 的性能
- 使用 OI (Operation Intensity) = MACs / weight 作为 x-axis
- 强调"fully weight-stationary (FWS) CIM architecture 消除了 memory-bound slant"

**与本文 framework 的差异**：
- 完全沿用 GPU Roofline 框架
- 未涉及 ADC / DAC 作为独立约束
- Roofline 的 x-axis 仍是 GPU 风格的 FLOPs/Byte

### 4.3 Roof-Surface (MICRO 2025, arXiv 2505.19349)

**标题**："3D Roof-Surface model for CPU with vector+matrix+memory"

**核心贡献**：
- 首次提出 **3D Roofline**：同时考虑 memory BW、vector compute、matrix compute
- 面向 CPU 的 SPR/AMX 架构
- x-axis: AIXM (MTX Ops/MEM Byte), AIXV (MTX Ops/VEC Op), z-axis: TFLOPS
- 处理 **3 种 resource 的约束**

**与本文 framework 的差异**：
- 针对 CPU 架构，与 CIM 无关
- **但验证了 "Roofline 可以扩展到高维 bound"** 的方法论——对 CIM 2D Roofline (见第 5 章) 是有益的先例

### 4.4 结论

**在 CIM / ACIM / NVM-CIM 领域，没有任何论文系统地提出"以 ADC/DAC interface 为独立 bound 的 Roofline 框架"**。现有工作要么把 CIM 塞进经典 Roofline (Verhelst, NSF)，要么不涉及 Roofline (大多数 CIM macro 论文)。

**→ 本文提出的 Producer-Consumer CIM Roofline，如果推导严格，将是该领域第一个原生 Roofline 框架。**

---

## 第五章 待解决的开放问题

当前候选方案有**5 个未完全 resolve 的 design decisions / concerns**，需要进一步讨论定型。

### 5.1 Y-axis 单位选择：outputs/sec vs MACs/sec

**方案 A (outputs/sec)**：量纲对偶美观，ceiling 纯 hardware
**方案 B (MACs/sec)**：贴近"有用 compute"，但 ceiling 带 workload 因子 OI

**未决问题**：
- 哪个更适合作为 CIM 的 "canonical" Roofline？
- 论文中是否应该 **同时呈现两个视图** (A 作为理论清洁版本，B 作为应用解读版本)？

### 5.2 X-axis intensity 定义：outputs/cycle vs outputs/input-value

当前方案 A 用 II = outputs/cycle (N_out)。另一种等价选择是 II' = outputs/input_value。

**两者只差一个常数因子**，但物理直觉略有不同：
- **Per-cycle**：slope 单位是 cycles/sec，更接近 "pipeline rate" 的 intuition
- **Per-input**：slope 单位是 inputs/sec，更接近 GPU 的 "bytes/sec" bandwidth intuition

**未决问题**：哪个更有 predictive 价值？

### 5.3 CIM 是否本质 2D (two-interface)？

CIM 物理上有 **两个独立数据流**（input 和 output）。
GPU 只有 **一个 memory channel**（input+output 共享）。

**这意味着 CIM Roofline 可能天然需要 2D 表达**：
- X-axis: Input Intensity (ICD = N_out, 每个 input 参与多少 MAC)
- Y-axis: Output Intensity (OCD = N_in, 每个 output 需要多少 MAC)
- Performance contour: min(ICD × B_supply, OCD × B_extract)

**未决问题**：
- 坚持 1D 投影（当前候选方案）是否本质丢失了信息？
- 2D 版本是否更能揭示 CIM 的独特 architecture characteristic？
- 对标 Roof-Surface (MICRO'25) 的 3D 扩展，CIM Roofline 可以借鉴其方法论吗？

### 5.4 Ceiling 是否应该 workload-dependent？

方案 A 的 ceiling (N_ADC / T_ADC) 是纯 hardware。
方案 B 的 ceiling (OI × N_ADC / T_ADC) 含 workload 因子。

**GPU Peak FLOPs 是纯 hardware**——Peak FLOPs 不依赖于 workload 大小。如果我们坚持对偶性，CIM ceiling 也应该纯 hardware，那方案 A 胜出。

**但另一种视角**：CIM 的 "有效 compute" 本来就和 workload shape (OI) 挂钩，workload-dependent ceiling 更真实反映"不同 workload 在同一硬件上能达到的峰值 compute"。

**未决问题**：纯 hardware ceiling (方案 A) 和 workload-reflecting ceiling (方案 B) 的 trade-off 该怎么定？

### 5.5 时间-空间复杂度对偶是否保持？

GPU Roofline 的 1.4 节 insight：
- x 轴 OPs/Byte = 空间复杂度
- y 轴 OPs/s = 时间复杂度

**CIM Roofline (候选 A) 的对应**：
- x 轴 outputs/cycle = ？（这不是严格的"空间复杂度"）
- y 轴 outputs/sec = 时间复杂度 ✓

**问题**：x 轴 outputs/cycle 更像是 **"pipeline structural intensity"**——每次 cycle 打包多少有效输出，而不是严格的"空间复杂度"。
- "cycle" 是时间单位，不是空间单位
- 所以 "outputs/cycle" 反映的是 **"每个 cycle 产出的密度"**，更像"操作密度"

**这可能是候选方案 A 的 dimensionally 问题**：时间-空间对偶在这里不清晰。

**未决问题**：
- 是否需要找一个更接近 GPU "space complexity" 含义的 x 轴？
- 对 CIM 来说，什么才是真正的 "空间复杂度" 维度？
  - 可能是：weight storage occupancy？
  - 可能是：input cache footprint？
  - 可能是：array utilization fraction？

### 5.6 可能需要重新考虑的根本问题

**CIM 的 weights 不移动，只有 inputs 和 outputs 流动**。这意味着 CIM 的 "访存量" 语义与 GPU 完全不同：

- GPU 中 "访存" = 权重 load + 激活 load/store (都计入 Byte)
- CIM 中 "访存" = 只有 input DAC 驱动 + output ADC 抽取 (weights 零搬运)

**这个根本差异可能导致整个 Roofline 的 x-axis 语义需要重新定义**——不是 "compute per data moved"，而是 "compute per cycle" 或 "compute per interface event"。

如果接受这一点，**第1章GPU Roofline 的"单位Byte"这一空间维度在 CIM 里根本不存在等价物**，Roofline 对偶性可能只能到某一层为止，更深层次会破裂。

**这是整个 CIM Roofline 框架最根本的不确定性**。

---

## 附录：关键参数速查表

| 参数 | 含义 | 典型值 |
|------|------|--------|
| T_array | 阵列 read cycle 延时 | ~14 ns |
| T_ADC | 单个 ADC 转换延时 | ~5-10 ns |
| N_ADC | 并行 ADC 数 | 16-128 (受面积预算限制) |
| T_DAC | 单个 DAC 转换延时 | ~1 ns (快) |
| N_WL_physical | 物理 WL 数 | 取决于阵列规模 |
| N_BL_physical | 物理 BL 数 | 取决于阵列规模 |
| II_ridge | CIM Roofline ridge | N_ADC × T_array / T_ADC ≈ 90 |

## 参考文献

- [GPU Roofline] S. Williams, A. Waterman, D. Patterson, "Roofline: an insightful visual performance model for multicore architectures," CACM 2009.
- [多级 Roofline + IMC] M. Verhelst, L. Benini, N. Verma, "How to keep pushing ML accelerator performance? Know your rooflines!", IEEE JSSC 2025. arXiv:2505.16346
- [3D Roof-Surface] G. Gerogiannis et al., MICRO 2025. arXiv:2505.19349
- [CIM Roofline comparison] NSF par 10526902, IEEE Nanotechnology Magazine 2024
- [FeNOR 器件基础] Y. Zhou et al., "3D NOR-Type FeFETs with Record Endurance...", VLSI 2025 / 2026

---

**文档状态**：候选方案待定，第 5 章问题尚未 resolve。讨论进行中。
